﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace MyReminder
{
    public partial class Edit : Form
    {
        public Edit()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
        public string conString = "Data Source=NBPRGLAB16\\SQLA;Initial Catalog=Event;User ID=sa;Password=admin123";
        SqlDataAdapter ad;
        private void Edit_Load(object sender, EventArgs e)
        {
            ShowData();


        }
        private void ShowData()
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            DataTable DT = new DataTable();
            ad = new SqlDataAdapter("select * from tbl_remind", con);
            ad.Fill(DT);
            dataGridView1.DataSource = DT;
            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
          
        }

        private void button2_Click(object sender, EventArgs e)
        {    
            SqlConnection con = new SqlConnection(conString);
                con.Open();
                if (con.State == System.Data.ConnectionState.Open)
                {
                    string qry = "update tbl_remind set dat='" + Txt_date.Text + "',time='" + Txt_time.Text + "',reminder='" + Txt_Eremind.Text + "' where r_id=" + Txt_id.Text + "";
                    SqlCommand cmd = new SqlCommand(qry, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Edited...");
                    ShowData();
                    con.Close();
                }
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
           
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Txt_id.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            Txt_date.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            Txt_time.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            Txt_Eremind.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
        }
    }
}
