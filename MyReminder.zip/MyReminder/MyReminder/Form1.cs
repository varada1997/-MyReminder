﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace MyReminder
   
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public string conString = "Data Source=NBPRGLAB16\\SQLA;Initial Catalog=Event;User ID=sa;Password=admin123";
        
        private void timeModule_ValueChanged(object sender, EventArgs e)
        {
            

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            TimePicker.Format = DateTimePickerFormat.Time;
            TimePicker.ShowUpDown = true;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();

            if (con.State == System.Data.ConnectionState.Open)
            {
                string qry = "insert into tbl_remind(dat,time,reminder)values('" + dateTimePicker1.Value.Date + "','" + TimePicker.Text+ "','" + Txt_Remin.Text + "')";
                SqlCommand cmd = new SqlCommand(qry, con);
                cmd.ExecuteNonQuery();
                if (Txt_Remin.Text == "")
                {
                    MessageBox.Show("Please add reminders.......!!!!");
                }
                else
                {
                    MessageBox.Show("Reminder created........!!!!");
                }
                con.Close();

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Txt_Remin.Clear();
            dateTimePicker1.ResetText();
            TimePicker.ResetText();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Edit nextform;
            nextform = new Edit();
            nextform.Show();

        }
    }
}
